create definer = root@localhost trigger after_class101_update
    after update
    on class101
    for each row
    INSERT INTO class101_audit SET action='Update', stuId=OLD.id, opDate=NOW();

