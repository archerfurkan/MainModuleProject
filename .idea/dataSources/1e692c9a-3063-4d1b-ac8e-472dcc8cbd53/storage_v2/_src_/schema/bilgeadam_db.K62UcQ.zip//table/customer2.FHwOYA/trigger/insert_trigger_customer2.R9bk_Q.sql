create definer = root@localhost trigger insert_trigger_customer2
    after insert
    on customer2
    for each row
    INSERT INTO customertrigger SET action='insert()', stuId=NEW.id, opDate=NOW();

