create definer = root@localhost trigger before_class101_gpa_update
    before update
    on class101
    for each row
BEGIN
	IF NEW.gpa > 5.00 THEN 
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT='GPA cannot be greater then 5.00';
    END IF;
END;

